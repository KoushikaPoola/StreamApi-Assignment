package distinctcount;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

     public class Test {

	    public static void main(String[] args) { 
		     Filter ft=new Filter();
		     Mapper mp=new Mapper();
		     List<String> names=Arrays.asList( "aaryanna", "aayanna", "airianna", "alassandra", "allanna", "allannah",
		                                  "allessandra", "allianna", "allyanna", "anastaisa", "anastashia", "anastasia", "annabella", "annabelle",
		                                  "annebelle");
		     names.stream()
		     .filter(ft.nameStartingWithPrefix("al"))
		     .map(mp.getDistinctCharactersCount())
		     .forEach(System.out::println);
		
            }

}





