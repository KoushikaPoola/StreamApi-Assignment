package distinctcount;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;

       public class Mapper {
               public static Function<String, CharactersCount> getDistinctCharactersCount(){
	                                           
		       return ch->
		                 {
			            Set<Character> characters = new HashSet<Character>();
			                for(char c: ch.toCharArray())
			                {
				            characters.add(new Character(c));
			                }
                                    Integer distinctcharacters=characters.size();
			            return new CharactersCount(ch, distinctcharacters);
			         };
	       }

       }
   








